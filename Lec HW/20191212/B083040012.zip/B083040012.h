#include<stdio.h>
#include<stdlib.h>

void mysort(int *array,int size);
int mtBinarySearch(int *array,int target,int head,int tail);
