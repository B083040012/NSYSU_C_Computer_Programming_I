#include<stdio.h>
#include<stdlib.h>

int main(){
	
	//Exercise 1
	
	int answer,low=0,high=500,sum=0,guess=0;
	
	printf("�п�J����(�d��:0~500):\n");
	scanf("%d",&answer);
	
	while(1){
		printf("\n�q�@�ӼƦr\n");
		scanf("%d",&guess);
		if(guess>answer && guess<high){
			high=guess;
			sum++;
			printf("\n�d��%d��%d",low,high);
		}
		else if(guess<answer && guess>low){
			low=guess;
			sum++;
			printf("\n�d��%d��%d",low,high);
		}
		else if(guess==answer){
			sum++;
			printf("\n���߲q��!!\n�A�q�F%d��\n\n\n",sum);
			break;
		}
			
		else{
			printf("\n�d��%d��%d",low,high);
			sum++; 
		} 	
	}
	
	//Exercise 2
	
	while(1){
		double m,n,mm=1,nm=1,mnm=1,i;
		printf("Input (m,n):");
		if((scanf("%lf %lf",&m,&n))==EOF)
			break;
		else if(!(0<=n&&n<=m&&m<=30)){
			printf("Wrong Range!! Please input another integer(0<=n<=m<=30)\n");
			continue;
		}
		else{
			for(i=m;i>=1;i--)
				mm*=i;
			for(i=n;i>=1;i--)
				nm*=i;
			for(i=(m-n);i>=1;i--)
				mnm*=i;
			printf("\nC(%.0lf, %.0lf) = %.0lf\n\n",m,n,mm/(nm*mnm));
		}	
	}

	return 0;
}

