#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define banana (len[0]>=len[1]+len[2]+len[3])||(len[1]>=len[0]+len[2]+len[3])||(len[2]>=len[0]+len[1]+len[3])||(len[3]>=len[0]+len[1]+len[2])

int main(){
	
	//Exercise 1
	
	int len[4], j=0 ,tem;
	
	printf("��J�|���:");
	while(j<=3){
		scanf("%d",&len[j]);
		j++;
	}
	
	if(len[0]==len[1]&&len[1]==len[2]&&len[2]==len[3]){
		printf("�٧�");
	}
	else if(len[0]==len[2]&&len[1]==len[3]){
		printf("����|���");
	}

	else if(banana){
		printf("Banana!");
	}
	else
		printf("��L�|���");
		
	printf("\n\n\n\t==========\n\n\n");
	
	//Exercise 2
	
	int oc[99999],hex[99999],i=0,a,b,in;
	double input,temp;
	
	printf("���:");
	scanf("%lf",&input);
	
	temp=(int)input;
	
	if(input-temp>0){
		printf("Error!");
	}
	else{
		in=(int)input;
		while(in>=8){
			a=in%8;
			oc[i]=a;
			i++;
			in=in/8;
		}
		oc[i]=in;
		printf("�K�i��:");
		for(i=i;i>=0;i--){
			printf("%d",oc[i]);
		}
		
		i=0;
		in=temp;
		
		while(in>=16){
			a=in%16;
			hex[i]=a;
			i++;
			in=in/16;
		}
		hex[i]=in;
		printf("\n�Q���i��:");
		for(i=i;i>=0;i--){
			if(hex[i]>=10){
				printf("%c",(char)(hex[i]+55));
			}
			else{
				printf("%d",hex[i]);
			}
		}
	}
	return 0;
}

